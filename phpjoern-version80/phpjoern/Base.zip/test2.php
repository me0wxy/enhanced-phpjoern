<?php

namespace Kanboard\Core\Controller;

use System\Framwork\BaseException;
/**
 * Class AccessForbiddenException
 *
 * @package Kanboard\Core\Controller
 * @author  Frederic Guillot
 */
class AccessForbiddenException extends BaseException
{

}

