<?php

namespace System\Framwork;

class BaseException extends Exception
{
    protected $withoutLayout = false;
}
